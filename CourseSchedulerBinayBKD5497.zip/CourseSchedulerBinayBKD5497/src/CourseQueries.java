/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Binay
 */
import java.lang.Object;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CourseQueries extends Object {

  private static        Connection conn;
  private static PreparedStatement selectAllCourses;
  private static PreparedStatement insertCourse;
  private static PreparedStatement selectAllCourseCodes;
  private static PreparedStatement selectCourseSeats;
  private static PreparedStatement deleteCourse;
  private static         ResultSet resultSet;

    /**
     *
     * @param semester
     * @return
     */
    public static ArrayList<CourseEntry> getAllCourses (String courseCode) {
    conn = DBConnection.getConnection();
    ArrayList<CourseEntry> results = new ArrayList<CourseEntry>();
    try {
      selectAllCourses = conn.prepareStatement("select * from app.courseCode where courseCode = ?");
      selectAllCourses.setString(1, courseCode);
      resultSet = selectAllCourses.executeQuery();
      while (resultSet.next()) {
        results.add(new CourseEntry(
          
          resultSet.getString("courseCode"),
          resultSet.getString("description")
              
                ));
      }
    }
    catch (SQLException se) {
      se.printStackTrace();
    }
    return results;
  }



  public static void addCourse (CourseEntry course) {
    conn = DBConnection.getConnection();
    try {
      insertCourse = conn.prepareStatement("insert into app.courses (courseCode, description) values (?, ?)");
      insertCourse.setString(1, course.getCourseCode());
      insertCourse.setString(2, course.getDescription());
      insertCourse.executeUpdate();
    }
    catch (SQLException se) {
      se.printStackTrace();
    }
  }
  
  


  public static ArrayList<String> getAllCourseCodes () {
    conn = DBConnection.getConnection();
    ArrayList<String> results = new ArrayList<String>();
    try {
      selectAllCourseCodes = conn.prepareStatement("select courseCode from app.courses order by courseCode");
      resultSet = selectAllCourseCodes.executeQuery();
      while (resultSet.next()) {
        results.add(resultSet.getString("courseCode"));
      }
    }
    catch (SQLException se) {
      se.printStackTrace();
    }
    return results;
  }

  
  

	
  public static void dropCourse (
                                 String courseCode)
  {
    conn = DBConnection.getConnection();
    try {
      deleteCourse = conn.prepareStatement("delete from app.courses where courseCode = ?");
      deleteCourse.setString(1, courseCode);
      deleteCourse.executeUpdate();
    }
    catch (SQLException se) {
      se.printStackTrace();
    }
  }

}
