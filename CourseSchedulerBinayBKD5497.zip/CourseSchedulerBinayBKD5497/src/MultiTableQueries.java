/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Binay
 */
//select app.class.courseCode, description, seats from app.class, app.course where semester = ? and app.class.courseCode = app.course.courseCode order by app.class.courseCode

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.lang.Object;

public class MultiTableQueries extends Object{
    
    private static        Connection conn;
  private static PreparedStatement selectAllClasses;
  private static PreparedStatement insertClass;
  private static PreparedStatement selectAllCourseCodes;
  private static PreparedStatement selectCourseSeats;
  private static PreparedStatement deleteCourse;
  private static         ResultSet resultSet;
  
  public static ArrayList<CourseDescription>getAllCourses (String semester){
      conn = DBConnection.getConnection();
      ArrayList<CourseDescription> results = new ArrayList<CourseDescription>();
      try {
          selectAllClasses = conn.prepareStatement("select app.classes.courseCode, description, seats from app.classes, app.courses where semester = ? and app.classes.courseCode = app.courses.courseCode order by app.classes.courseCode");
          selectAllClasses.setString(1,semester);
          resultSet = selectAllClasses.executeQuery();
         while (resultSet.next()) {
               results.add(new CourseDescription(
               resultSet.getString("courseCode"),
               resultSet.getString("description"),
               resultSet.getInt("seats")
                ));
        }
      }
      catch (SQLException se) {
      se.printStackTrace();
      }
  return results; 
    
  }
  
  public static ArrayList<String> getAllCourseCodes (String semester) {
    conn = DBConnection.getConnection();
    ArrayList<String> results = new ArrayList<String>();
    try {
      selectAllCourseCodes = conn.prepareStatement("select courseCode from app.classes where semester = ?");
      selectAllCourseCodes.setString(1, semester);
      resultSet = selectAllCourseCodes.executeQuery();
      while (resultSet.next()) {
        results.add(resultSet.getString("courseCode"));
      }
    }
    catch (SQLException se) {
      se.printStackTrace();
    }
    return results;
  }
}
