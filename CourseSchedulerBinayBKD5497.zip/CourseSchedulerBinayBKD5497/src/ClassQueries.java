/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Binay
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.lang.Object;


public class ClassQueries extends Object {

  private static        Connection conn;
  private static PreparedStatement selectAllClasses;
  private static PreparedStatement insertClass;
  private static PreparedStatement selectAllCourseCodes;
  private static PreparedStatement selectCourseSeats;
  private static PreparedStatement deleteCourse;
  private static         ResultSet resultSet;
  
  public static void addCourse (ClassEntry course){
      conn = DBConnection.getConnection();
      try {
          insertClass = conn.prepareStatement("insert into app.classes (semester, courseCode, seats) values (?, ?, ?)");
          insertClass.setString(    1,    course.getSemester());
          insertClass.setString(   2,    course.getCourseCode());
          insertClass.setInt(3, course.getSeats());
          insertClass.executeUpdate();
        }
      catch (SQLException se) {
      se.printStackTrace();
      }
  }
  
  public static ArrayList<ClassEntry> getAllCourses (String semester) {
    conn = DBConnection.getConnection();
    ArrayList<ClassEntry> results = new ArrayList<ClassEntry>();
    try {
      selectAllClasses = conn.prepareStatement("select * from app.classes where semester = ?");
      selectAllClasses.setString(1,semester);
      resultSet = selectAllClasses.executeQuery();
      while (resultSet.next()) {
        results.add(new ClassEntry(
               resultSet.getString("semester"),
               resultSet.getString("courseCode"),
               resultSet.getInt("seats")
                
          
                ));
      }
      
    }
    catch (SQLException se) {
      se.printStackTrace();
    }  
    return results;
  }
    
 
   
    public static ArrayList<String> getAllCourseCodes (String semester) {
    conn = DBConnection.getConnection();
    ArrayList<String> results = new ArrayList<String>();
    try {
      selectAllCourseCodes = conn.prepareStatement("select courseCode from app.classes where semester = ?");
      selectAllCourseCodes.setString(1, semester);
      resultSet = selectAllCourseCodes.executeQuery();
      while (resultSet.next()) {
        results.add(resultSet.getString("courseCode"));
      }
    }
    catch (SQLException se) {
      se.printStackTrace();
    }
    return results;
  }
   

    public static int getCourseSeats (
                                    String semester,String courseCode)
  {
    conn = DBConnection.getConnection();
    try {
      selectCourseSeats = conn.prepareStatement("select seats from app.classes where semester = ? and courseCode = ?");
      selectCourseSeats.setString(1, semester);
      selectCourseSeats.setString(2, courseCode);
      resultSet = selectCourseSeats.executeQuery();
      resultSet.next();
      return resultSet.getInt("seats");
    }
    catch (SQLException se) {
      se.printStackTrace();
      return 0;
    }
  }
}