/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Binay
 */
import java.lang.Object;
import java.sql.Timestamp;

public class ScheduleEntry extends Object {

  private    String SEMESTER;
  private    String COURSECODE;
  private    String STUDENTID;
  private      char STATUS;
  private Timestamp TIMESTAMP;


  // constructor
  public ScheduleEntry () {}
  public ScheduleEntry (String SEMESTER,
                        String COURSECODE ,
                        String STUDENTID,
                          char STATUS,
                     Timestamp TIMESTAMP)
  {
    this.SEMESTER   = SEMESTER;
    this.COURSECODE = COURSECODE;
    this.STUDENTID  = STUDENTID;
    this.STATUS     = STATUS;
    this.TIMESTAMP  = TIMESTAMP;
  }
  // END constructor


  // getters
  public    String getSemester   () { return SEMESTER; }
  public    String getCourseCode () { return COURSECODE; }
  public    String getStudentID  () { return STUDENTID; }
  public      char getStatus     () { return STATUS; }
  public Timestamp getTimestamp  () { return TIMESTAMP; }
  // END getters


  // string representation of object `ScheduleEntry`
  @Override
  public String toString () {
    return String.format(
      "Schedule Entry%n%s%n%s%n%s%n%d%n%s%n%n",
      getSemester(),
      getCourseCode(),
      getStudentID(),
      getStatus(),
      getTimestamp()
    );
  }

}
