/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Binay
 */
import java.lang.Object;

public class CourseEntry extends Object {

  private String courseCode;
  private String description;
  
 


  // constructor
  public CourseEntry () {}
  public CourseEntry (
                      String courseCode,
                      String description
                     )
  {
    
    this.courseCode  = courseCode;
    this.description = description;
    
    
  }
  // END constructor

    


  // getters
  
  public String getCourseCode  () { return courseCode; }
  public String getDescription () { return description; }
  
  // END getters

  
  // string representation of object `CourseEntry`
  @Override
    public String toString () {
    return String.format(
      "%s",
      getCourseCode()
    );
  }

}

